"""
This file contains references to external DLLs.
Feel free to add as required.
Please do not put any paths in here, use RhinoPython -> ImportManager instead!
"""
 
import clr
clr.AddReference("RhinoCommon.dll")
